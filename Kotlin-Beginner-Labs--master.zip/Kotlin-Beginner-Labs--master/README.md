# Kotlin-Beginner-Labs-
All labs covered in the first three weeks of yr2, semester 2
