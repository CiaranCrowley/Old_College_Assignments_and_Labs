fun main(args: Array<String>){

    val myArray = arrayOf(4, 5, 6, 7)
    println(myArray.asList())
    println(myArray[2])

    val myMixedArray = arrayOf(4, 5, 6, 7, "mixed", "type", "allowed")
    println(myMixedArray.asList())
    println(myMixedArray)

    val intArray1 = intArrayOf(4, 5, 6, 7)
    val intArray2 = arrayOf<Int>(4, 5, 6, 7)
    val charArray = charArrayOf('a', 'b', 'c', 'd')
    val booleanArray = booleanArrayOf(true, false, true)

    println("IntArray1 : ${intArray1.asList()} and is type ${intArray1.javaClass.typeName}")
    println("IntArray2 : ${intArray2.asList()} and is type ${intArray2.javaClass.typeName}")
    println("charArray : ${charArray.asList()} and is type ${charArray.javaClass.typeName}")
    println("booleanArray : ${booleanArray.asList()} and is type ${booleanArray.javaClass.typeName}")

    val intArray = Array(6, {i -> i*2})
    println("Array using Constructor: ${intArray.asList()}")

    val fruit = mutableListOf("Banana", "Kiwifruit", "Mango", "Apple")
    println("Mutable List ${fruit}")

    //add an item
    fruit.add("Pear")
    println("Mutable List ${fruit}")

    //update an item
    fruit[1] = "Orange"
    println("Mutable List ${fruit}")

    //remove an item
    fruit.removeAt(2)
    println("Mutable List ${fruit}")

    println("\n")

    val mutableNumbers: MutableList<Int> = mutableListOf(1, 2, 3)
    val readOnlyView: List<Int> = mutableNumbers

    println("Mutable numbers: ${mutableNumbers}")   //prints "[1, 2, 3]"
    mutableNumbers.add(4)

    println("Read only view: ${readOnlyView}")      //prints "[1, 2, 3, 4]"

    //Iterating over the list
    for(fruitItem in fruit) {
        println(fruitItem)
    }

    println("\nUsing Lambdas:\n")
    fruit.filter {it.contains("an")}.sortedByDescending {it}
        .map {it.toUpperCase()}.forEach  {println(it)}
}