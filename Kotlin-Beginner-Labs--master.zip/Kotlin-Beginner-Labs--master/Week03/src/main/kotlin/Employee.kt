data class Employee(var firstName: String, var lastName: String){

}