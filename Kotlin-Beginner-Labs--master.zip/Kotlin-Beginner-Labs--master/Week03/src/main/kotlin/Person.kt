class Person(_firstName: String = "UNKNOWN FIRSTNAME", _lastName: String = "UNKNOWN LASTNAME"){

    var firstName = _firstName
        get() = field

    var lastName = _lastName
        get() = field
        //Setter code
        set(value){
            field = value.toUpperCase()
        }

    //initialisation  block
    init {
        println("First Name = ${firstName}")
        println("Surname = ${lastName}")
    }
}