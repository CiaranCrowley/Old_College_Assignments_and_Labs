fun main(args: Array<String>){
//    var person = Person("Joe")
//    var person2 = Person("Joe", "Murphy")
//    var person3 = Person()
//    person2.lastName = "flynn"
//    println("Updated Person 2 Surname: ${person2.lastName}")

//    println("First Name = ${person.firstName}")
//    println("Surname = ${person.lastName}")

    val employee1 = Employee("Mark", "Roche")
    val employee2 = employee1.copy(firstName = "Clare")
    println(employee1)
    println(employee2.toString())
    val employee3 = employee1.copy()

    println("employee1 hashcode = ${employee1.hashCode()}")
    println("employee2 hashcode = ${employee2.hashCode()}")
    println("employee3 hashcode = ${employee3.hashCode()}")

    if(employee1.equals(employee2)){
        println("employee1 is equal to empoyee 2.")
    }else{
        println("employee1 is not equal to employee3.")
    }

    if(employee1.equals(employee3)){
        println("employee1 is equal to employee3.")
    }else{
        println("employee1 is not equal to employee3.")
    }
}