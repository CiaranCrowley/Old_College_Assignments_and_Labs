package org.wit.reminder.activities

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.card_reminder.view.*
import org.wit.reminder.R
import org.wit.reminder.helpers.readImage
import org.wit.reminder.helpers.readImageFromPath
import org.wit.reminder.models.ReminderModel

interface ReminderListener {
    fun onReminderClick(reminder: ReminderModel)
}

class ReminderAdapter constructor(private var reminders: List<ReminderModel>,
                                  private val listener: ReminderListener) : RecyclerView.Adapter<ReminderAdapter.MainHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainHolder {
        return MainHolder(LayoutInflater.from(parent?.context).inflate(R.layout.card_reminder, parent, false))
    }

    override fun onBindViewHolder(holder: MainHolder, position: Int) {
        val reminder = reminders[holder.adapterPosition]
        holder.bind(reminder, listener)
    }

    override fun getItemCount(): Int = reminders.size

    class MainHolder constructor(itemView: View) : RecyclerView.ViewHolder(itemView) {

        fun bind(reminder: ReminderModel,  listener : ReminderListener) {
            itemView.reminderTitle.text = reminder.title
            itemView.description.text = reminder.description
            itemView.imageIcon.setImageBitmap(readImageFromPath(itemView.context, reminder.image))
            itemView.setOnClickListener { listener.onReminderClick(reminder) }
        }
    }
}