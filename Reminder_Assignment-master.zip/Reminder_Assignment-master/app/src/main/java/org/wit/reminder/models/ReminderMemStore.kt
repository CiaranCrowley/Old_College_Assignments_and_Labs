package org.wit.reminder.models

import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.info

var lastId = 0L

internal fun getId(): Long {
    return lastId++
}

class ReminderMemStore : ReminderStore, AnkoLogger{

    val reminders = ArrayList<ReminderModel>()

    override fun findAll(): List<ReminderModel>{
        return reminders
    }

    override fun create(reminder: ReminderModel) {
        reminders.add(reminder)
        logAll()
    }

    override fun update(reminder: ReminderModel) {
        var foundReminder: ReminderModel? = reminders.find { p -> p.id == reminder.id }
        if (foundReminder != null) {
            foundReminder.title = reminder.title
            foundReminder.description = reminder.description
            foundReminder.date = reminder.date
            foundReminder.image = reminder.image
            foundReminder.lat = reminder.lat
            foundReminder.lng = reminder.lng
            foundReminder.zoom = reminder.zoom
            logAll()
        }
    }

    override fun delete(placemark: ReminderModel) {
        reminders.remove(placemark)
    }

    fun logAll(){
        reminders.forEach{ info("${it}")}
    }
}