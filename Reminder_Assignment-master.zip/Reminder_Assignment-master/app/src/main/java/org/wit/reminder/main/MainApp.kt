package org.wit.reminder.main

import android.app.Application
import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.info
import org.wit.reminder.models.ReminderJSONStore
import org.wit.reminder.models.ReminderStore

class MainApp : Application(), AnkoLogger {

    lateinit var reminders: ReminderStore

    override fun onCreate() {
        super.onCreate()
        reminders = ReminderJSONStore(applicationContext)
        info("Reminder started")
    }
}