package org.wit.reminder.activities

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.app.DatePickerDialog
import android.content.Intent
import android.view.Menu
import android.view.MenuItem
import kotlinx.android.synthetic.main.activity_reminder.*
import org.jetbrains.anko.AnkoLogger
import org.jetbrains.anko.info
import org.jetbrains.anko.intentFor
import org.jetbrains.anko.toast
import org.wit.reminder.main.MainApp
import org.wit.reminder.R
import org.wit.reminder.helpers.readImage
import org.wit.reminder.helpers.readImageFromPath
import org.wit.reminder.helpers.showImagePicker
import org.wit.reminder.models.Location
import org.wit.reminder.models.ReminderModel
import java.text.SimpleDateFormat
import java.util.*

class ReminderActivity : AppCompatActivity(), AnkoLogger {

    var reminder = ReminderModel()
    var edit = false
    val IMAGE_REQUEST = 1
    lateinit var app: MainApp
    val LOCATION_REQUEST = 2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reminder)
        app = application as MainApp

        if(intent.hasExtra("reminder_edit")){
            edit = true
            reminder = intent.extras.getParcelable<ReminderModel>("reminder_edit")
            reminderTitle.setText(reminder.title)
            description.setText(reminder.description)
            //Saves Date
            showDate.setText(reminder.date)
            btnAdd.setText(R.string.save_reminder)
            reminderImage.setImageBitmap(readImageFromPath(this, reminder.image))
            if(reminder.image != null){
                chooseImage.setText(R.string.change_reminder_image)
            }
        }

        btnAdd.setOnClickListener {
            reminder.title = reminderTitle.text.toString()
            reminder.description = description.text.toString()
            reminder.date = showDate.text.toString()
            if (reminder.title.isEmpty()) {
                toast(R.string.enter_reminder_title)
            }else{
                if(edit){
                    app.reminders.update(reminder.copy())
                }else{
                    app.reminders.create(reminder.copy())
                }
            }
            info("add Button Pressed: $reminderTitle")
            setResult(AppCompatActivity.RESULT_OK)
            finish()
        }

        //Date Picker  (https://stackoverflow.com/questions/45842167/how-to-use-datepickerdialog-in-kotlin#45844018)
        var cal = Calendar.getInstance()
        val dateSetListener = DatePickerDialog.OnDateSetListener{ view, year, month, dayOfMonth ->
            cal.set(Calendar.YEAR, year)
            cal.set(Calendar.MONTH, month)
            cal.set(Calendar.DAY_OF_MONTH, dayOfMonth)

            val format = "dd.MM.yyy"
            val sdf = SimpleDateFormat(format, Locale.UK)
            showDate.text = sdf.format(cal.time)
        }

        //Show Date Picker
        pickDate.setOnClickListener{
            DatePickerDialog(this, dateSetListener,
                cal.get(Calendar.YEAR),
                cal.get(Calendar.MONTH),
                cal.get(Calendar.DAY_OF_MONTH)).show()
        }

        chooseImage.setOnClickListener {
            showImagePicker(this, IMAGE_REQUEST)
        }

        reminderLocation.setOnClickListener{
            val location = Location(52.245696, -7.139102, 15f)
            if(reminder.zoom != 0f){
                location.lat = reminder.lat
                location.lng = location.lng
                location.zoom  = location.zoom
            }
            startActivityForResult(intentFor<MapsActivity>().putExtra("location", location), LOCATION_REQUEST)
        }

        toolbarAdd.title = title
        setSupportActionBar(toolbarAdd)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean{
        menuInflater.inflate(R.menu.menu_reminder, menu)
        if (edit && menu != null) menu.getItem(0).setVisible(true)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        when (item?.itemId) {
            R.id.item_delete -> {
                app.reminders.delete(reminder)
                finish()
            }
            R.id.item_cancel -> {
                finish()
            }
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            IMAGE_REQUEST -> {
                if (data != null) {
                    reminder.image = data.getData().toString()
                    reminderImage.setImageBitmap(readImage(this, resultCode, data))
                    chooseImage.setText(R.string.change_reminder_image)
                }
            }
            LOCATION_REQUEST -> {
                if (data != null) {
                    val location = data.extras.getParcelable<Location>("location")
                    reminder.lat = location.lat
                    reminder.lng = location.lng
                    reminder.zoom = location.zoom
                }
            }
        }
    }
}


