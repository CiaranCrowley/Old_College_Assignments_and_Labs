# Car_Valeting_Manager
An App that Manages a Valeting service.
This app allows a business owner to create bookings for customers who wish to get their vehicle valeted.
A user can login using their phone number, email, or Googel account and create bookings for their cars.
They can update and delete their bookings.
The user bookings are stored in a real time firebase database.
They can set personal profile pictures in the app, whhich are stored on firebase.
