package ie.wit.main

import android.os.Parcelable
import com.google.firebase.database.Exclude
import com.google.firebase.database.IgnoreExtraProperties
import kotlinx.android.parcel.Parcelize

@IgnoreExtraProperties
@Parcelize
data class UserPhotoModel(
    var uid: String? = "",
    var profilepic: String = ""): Parcelable {
    @Exclude
    fun toMap(): Map<String, Any?>{
        return mapOf(
            "uid" to uid,
            "profilepic" to profilepic
        )
    }
}