Welcome to the Glitch Template 1
==============================

A starter project for learning Glitch.

This is an Express.js project, designed to work well with the Glitch development environment. It includes basic express setup, templating, routing and session support.
