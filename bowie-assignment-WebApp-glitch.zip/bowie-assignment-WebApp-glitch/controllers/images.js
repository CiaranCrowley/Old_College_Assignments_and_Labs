'use strict';

const logger = require('../utils/logger');

const images ={
  index(request, response){
    const viewData = {
      title: 'Image Gallary',
    };
    response.render('images', viewData);
  },
};

module.exports = images;