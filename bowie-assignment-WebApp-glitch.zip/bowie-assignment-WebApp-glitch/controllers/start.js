'use strict';

const logger = require('../utils/logger');
const accounts = require ('./accounts.js');
const playlistStore = require ('../models/playlist-store.js');

const start = {
  index(request, response) {
      const loggedInUser = accounts.getCurrentUser(request);  
    logger.info('start rendering');
    if (loggedInUser) {
      const playCollections = playlistStore.getUserPlaylists();
      let totalSongs = 0;
      for(let i in playCollections){
        totalSongs = totalSongs +playCollections[i].songs.length;
      }
      
    const viewData = {
      title: 'Welcome to Playlist 1',
      fullname: loggedInUser.firstName + ' ' + loggedInUser.lastName,
      totalCollections: playCollections.length,
      totalSongs: totalSongs,
    };
    response.render('start', viewData);
    }
    else response.redirect('/');
  },
};

module.exports = start;
